const cars = [
    "Saab",
    "Volvo",
    "BMW"
  ];
for(i=0;i<3;i++)
{
    console.log(cars[i])
}
