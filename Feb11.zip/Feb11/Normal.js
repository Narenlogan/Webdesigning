let p={
    name:"Jeeva",
    age:"30",
    salary:30000,
}

console.log(p.salary);
